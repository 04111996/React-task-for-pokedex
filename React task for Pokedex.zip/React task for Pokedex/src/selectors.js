export const selectDataTable = (table: string) => state =>
  state.datatable[table];
