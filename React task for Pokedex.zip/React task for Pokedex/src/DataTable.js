import enhanceDataTable from './enhanceDataTable';
import PartialTable from './PartialTable';

export default enhanceDataTable(PartialTable);
